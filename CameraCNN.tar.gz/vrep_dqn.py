import numpy as np
import random
from collections import deque
import keras 
from keras.models import Sequential, load_model,Model
from keras import optimizers
from keras.layers import Dense,Dropout,Activation,Concatenate,Merge
from keras.layers.advanced_activations import LeakyReLU
from keras.utils import plot_model
from keras import initializers
from keras.layers import Conv2D,MaxPooling2D,Flatten
import matplotlib.pyplot as plt
from scipy import misc

# If your image batch is of N images of HxW size with C channels, theano uses the NCHW ordering while tensorflow uses the NHWC ordering.
# https://stackoverflow.com/questions/43196636/how-to-concatenate-two-layers-in-keras
resolution = 64

class DQNAgent:
	def __init__(self, state_size, action_size,hiddenLayers,activation_function):
	 

		# get size of state and action
		self.state_size = state_size
		self.action_size = action_size
		self.img_size = (1,resolution,resolution,3)

		# These are hyper parameters for the DQN
		self.hiddenLayers = hiddenLayers
		self.activationType = activation_function
		self.discount_factor = 0.9
		self.learning_rate = 0.01
		self.epsilon = 1.0
		self.epsilon_decay = 0.9995
		self.epsilon_min = 0.01
		self.batch_size = 5
		self.train_start = 10
		# create replay memory using deque
		self.memory = deque(maxlen=10000)

		# create main model and target model
		self.model = self.build_model(self.hiddenLayers,self.activationType)
		self.target_model = self.build_model(self.hiddenLayers,self.activationType)
		print(self.model,"5555555555555555")
		# print(self.model.summary())
		# initialize target model
		# self.update_target_model()




	# approximate Q function using Neural Network
	# state is input and Q Value of each action is output of network


	def build_model(self, hiddenLayers, activationType):
		input_shape = (resolution,resolution,3)
		cnn_model = Sequential()
		cnn_model.add(Conv2D(32, kernel_size=(5, 5), strides=(1, 1),name='l1',
		                 activation='relu',
		                 input_shape=input_shape))
		cnn_model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2)))
		cnn_model.add(Conv2D(64, (5, 5), activation='relu',name='l2'))
		cnn_model.add(MaxPooling2D(pool_size=(2, 2)))
		cnn_model.add(Flatten())
		cnn_model.add(Dense(60, activation='relu',name='l3'))
		# cnn_model.summary()
		plot_model(cnn_model,show_shapes=True, to_file='cnn_model.png')
		# model.add(Dense(num_classes, activation='softmax'))
				# ------------------

		ann_model = Sequential()
		if len(hiddenLayers) == 0: 
			ann_model.add(Dense(self.action_size, input_dim=self.state_size)  ) # ann_model.add(Dense(self.output_size, input_shape=(self.state_size,))  ) #
			ann_model.add(Activation("linear"))
		else :
			ann_model.add(Dense(hiddenLayers[0], input_dim = self.state_size) )
				
			for index in range(1, len(hiddenLayers)):
				
				layerSize = hiddenLayers[index]
				ann_model.add(Dense(layerSize))
				ann_model.add(Activation(self.activationType))

		# ann_model.summary()
		plot_model(ann_model,show_shapes=True, to_file='ann_model.png')
	# ----------------------------------------------------------------
		model = Sequential()
		model.add(Merge([cnn_model,ann_model], mode = 'concat') )
		# merge = Concatenate([cnn_model, model])
		# final = Sequential()
		# final.add(Merge([cnn_model,model],mode = 'concat'))
		model.add(Dense(self.action_size,input_shape=(1,)))
		model.add(Activation("linear"))

		# result = Concatenate([merge,final])

		# optimizer = optimizers.RMSprop(lr=self.learningRate, rho=0.9, epsilon=1e-06)
		optimizer = optimizers.SGD(lr=self.learning_rate, clipnorm=1.)
		# optimizer = optimizers.Adam(lr=self.learning_rate)
	
		# modelM = Model(inputs=[first_input, second_input, third_input], outputs=merge_two)
		# model.summary()
		plot_model(model, show_shapes=True,to_file='model.png')
		model.compile(loss="mse", optimizer=optimizer)

		self.intermediate_layer_model =  Model(inputs=model.input,   outputs=model.get_layer(name='l1').output)
		return model

	# after some time interval update the target model to be same with model
	def save_cnn_image(self,state,img,episode_num):


		x = np.shape(img)[0]
		y= np.shape(img)[1]
		z = np.shape(img)[2]
		img = np.reshape(img,(1,x,y,z))
		# self.target_model.set_weights(self.model.get_weights())

		desiredLayers = [1,2]
		# print(len(self.model.layers))
		
		# print(self.model.layers)
		intermediate_output = self.intermediate_layer_model.predict([img,state])
		# print(len(intermediate_output))
		# name = l2 or l1

		desiredOutputs = [self.model.get_layer(name='l2').output for i in desiredLayers]
		newModel = Model(self.model.inputs, desiredOutputs)

		# print(intermediate_output)
		# print(np.shape(intermediate_output))
		arr = newModel.predict([img,state])
		print(np.shape(arr[0][0]))
		a,b,c = np.shape(arr[0][0])
		print(a,b,c)
		arr = arr[0]
		print(np.shape(arr))
		for filter_ in range(c):
			# Get the 5x5x1 filter:
			extracted_filter = arr[:, :, :, filter_]
			print(np.shape(extracted_filter))
			# Get rid of the last dimension (hence get 5x5):
			extracted_filter = np.squeeze(extracted_filter)

		# 	# 	# display the filter (might be very small - you can resize the window)
			misc.imshow(extracted_filter)
		# 	# 	plt.imshow(arr[0,:,:,1])
		# 	# 	plt.savefig('Images/'+str(1)+'.png')

		# out = np.squeeze(intermediate_output,axis=0)
		# # out = np.reshape(out,out.shape[:2])
		# # print(np.shape(out[:,:,0]))
		# plt.imshow(out[:,:,0])
		# plt.savefig('Images/'+str(episode_num)+'.png')
		# pass

	def update_epsilon(self):
		if self.epsilon > self.epsilon_min:
			self.epsilon *= self.epsilon_decay

	# get action from model using epsilon-greedy policy
	def get_action(self, state, img):

		

		x = np.shape(img)[0]
		y= np.shape(img)[1]
		z = np.shape(img)[2]
		img = np.reshape(img,(1,x,y,z))


		if np.random.rand() <= self.epsilon:
			action = random.randrange(self.action_size)
			print("Random Action ", action)
			return action
		else:
			q_value = self.model.predict([img,state])
			print("Action = ",np.argmax(q_value[0]))

			return np.argmax(q_value[0])

	# save sample <s,a,r,s'> to the replay memory
	def append_sample(self, state, img, action, reward, next_state, next_img, done):
		self.memory.append((state, img, action, reward, next_state, next_img, done))
	
	def ready_to_train(self):
		if len(self.memory) < self.train_start:
			return False
		return True


	# pick samples randomly from replay memory (with batch_size)
	def train_model(self):
		print("inside training")

		# if not ready_to_train():
			# return
		
		batch_size = min(self.batch_size, len(self.memory))
		mini_batch = random.sample(self.memory, batch_size)

		update_input = np.zeros((batch_size, self.state_size))
		update_input_img = np.zeros((batch_size, self.img_size[1],self.img_size[2],self.img_size[3]))
		update_target = np.zeros((batch_size, self.state_size))
		update_target_img = np.zeros((batch_size, self.img_size[1],self.img_size[2],self.img_size[3]))

		action, reward, done = [], [], []
		# print(np.shape(mini_batch[0][5]), np.shape(update_target_img[0]))
		# print(np.shape(update_target))
		for i in range(self.batch_size):
			update_input[i] = mini_batch[i][0]
			update_input_img[i] = mini_batch[i][1]
			action.append(mini_batch[i][2])
			reward.append(mini_batch[i][3])
			update_target[i] = mini_batch[i][4]
			update_target_img[i] = mini_batch[i][5]
			done.append(mini_batch[i][6])

		target = self.model.predict([update_input_img, update_input])
		# target_val = self.target_model.predict(update_target)
		target_val = self.model.predict([update_target_img, update_target])

		for i in range(self.batch_size):
			# Q Learning: get maximum Q value at s' from target model
			if done[i]:
				target[i][action[i]] = reward[i]
			else:
				target[i][action[i]] = reward[i] + self.discount_factor * (
					np.amax(target_val[i]))

		# and do the model fit!
		self.model.fit([update_input_img, update_input], target, batch_size=self.batch_size,
					   epochs=1, verbose=1)


	def saveQValues(self,episode_num,file_path,state_size,t2,t1):
		
		m, s = divmod(int(t2 - t1), 60)
		h, m = divmod(m, 60)
		img = np.zeros((resolution,resolution,3))
		img = np.reshape(img,(1,resolution,resolution,3))


		f = open(file_path,'a')
		print( '\nQ VALUES for ',episode_num , "Time: %d:%02d:%02d" % (h, m, s),file = f)
		state = np.array([0,0,0])
		for i in range (13,22,3):
			for j in range(13,22,3):
				for k in range(13,23,3):
					state = np.array([i/100,j/100,k/100])
					state = np.reshape(state, [1, state_size])

					predicted = self.model.predict([img,state])
					print(state,' -> ', predicted[0],file = f)


		f.close()

	def saveQActions(self,episode_num,file_path,state_size):
		f = open(file_path,'a')
		img = np.zeros((resolution,resolution,3))
		img = np.reshape(img,(1,resolution,resolution,3))

		print( '\nQ VALUES for ',episode_num,file = f)
		state = np.array([0,0,0])
		for i in range (13,22,3):
			for j in range(13,22,3):
				for k in range(13,23,3):
					state = np.array([i/100,j/100,k/100])
					state = np.reshape(state, [1, state_size])

					q_value = self.model.predict([img,state])
					print(state,' -> ', np.argmax(q_value[0]),file = f)


		f.close()


	def saveWeights(self,episode_num):
		f = open('Files/Wval.txt','a')
		print(self.model.get_weights(),file=f)
		# print( '\nWeight VALUES for ',episode_num,file = f)
		# for layer in self.model.layers:
			# weights = layer.get_weights()
			# print(weights,file = f)