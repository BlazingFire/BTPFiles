import deepQ
import matplotlib.pyplot as plt
import pickle
import time
import h5py
import os, os.path
import numpy as np

epsilon = 1
inputs = 3 #state
outputs = 3 #action
dicountFactor = 0.9
learningRate = 0.5
savePath='pioneer_qlearn_deep/ep'
network_layers = [6,5]
graphPath = 'Images/'
rewardFile = 'Files/rewards.pickle'
stepFile = 'Files/steps.pickle'
epsilon_decay = 0.9995
# memory = Memory(MEMORY_CAPACITY)
batch_size = 32


deepQLearn = deepQ.NNQ(inputs,outputs,dicountFactor,learningRate)
deepQLearn.initNetworks(network_layers)

file_count= len([name for name in os.listdir('pioneer_qlearn_deep') ])
weights_path = 'pioneer_qlearn_deep/ep208.h5'
deepQLearn.loadWeights(weights_path)


model_new = deepQLearn.model
# new


def getQValues( state, model):
	# predicted = self.model.predict(state.reshape(1,len(state)))
	predicted = model.predict(state.reshape(1,len(state)))
	return predicted[0]

state = np.array([ 0.19,  0.35,  0.35])
print(getQValues(state,model_new))


weights_path = 'pioneer_qlearn_deep/ep207.h5'
deepQLearn.loadWeights(weights_path)

model_old = deepQLearn.model

print(getQValues(state,model_old))