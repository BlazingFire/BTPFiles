import qEnvironment
import deepQ
import time
import h5py
import os, os.path
import matplotlib.pyplot as plt
import pickle
import numpy as np
import random
from SumTree import SumTree

'''
	Agents : Takes Action in the environment,sets up simulation(Episodes, step size)
	Environment : sets up the environment(v-rep simulation), returns rewards and next states to agent based on the actions it took
	Algorithm :  The Learning Algorithm
'''

MEMORY_CAPACITY = 200000 # max_buffer_size

class Agent:
	def __init__(self):
		self.epsilon = 0
		self.inputs = 5 #state , sensor + vel
		self.outputs = 3 #action
		self.dicountFactor = 0.9
		self.learningRate = 0.5
		self.savePath='pioneer_qlearn_deep/ep'
		self.network_layers = [6,5]
		self.graphPath = 'Images/'
		self.rewardFile = 'Files/rewards.pickle'
		self.stepFile = 'Files/steps.pickle'
		self.epsilon_decay = 0.99956
		self.memory = Memory(MEMORY_CAPACITY)
		self.batch_size = 32
		
		

	def start(self):
		
		# base = 3
		file_count= len([name for name in os.listdir('pioneer_qlearn_deep') ])
		# print("FILE",file_count)
		weights_path = 'pioneer_qlearn_deep/ep'+str(file_count)+'.h5'
		deepQLearn = deepQ.NNQ(self.inputs,self.outputs,self.dicountFactor,self.learningRate)
		deepQLearn.initNetworks(self.network_layers)
		
		#deepQLearn.plotModel('/home/kaizen/BTP/Python/NeuralNet/Images/')		

		if file_count != 0:
			deepQLearn.loadWeights(weights_path)
			print("Weights Loaded from path ",weights_path,"\n")

		env = qEnvironment.Environment()


		num_episodes = 12000
		steps = 800
		start_time = time.time()

		#  for plotting,data per episode
		stepList = []
		rewardList = []
		index = 1
		
		# replay = []  # stores tuples of (S, A, R, S').
		total_steps_in_simulation = 0
		observe = 2000
				# max_buffer_size = 10000 # average 30 steps, 10000/30 = 333 episodes 
		

		for episode in range(num_episodes):
			# if ((episode+1)%200 ==0 and self.epsilon > 0.13):
			# 	self.epsilon = self.epsilon - 0.1
			# if (episode+1)%200 ==0 and (episode+1) >1000:
			# 	self.epsilon -= 0.01	
			state = env.reset()
			env.disable_gui()

			self.epsilon *= self.epsilon_decay 
			cumulated_reward = 0
			
			for step in range(steps):

				print("state = ",state,end="" )

				qValues = deepQLearn.getQValues(state)
				action = deepQLearn.selectAction(qValues, self.epsilon )
				# self.dict[''.join(str(e) for e in state)] = action

				vl,vr = env.step_(action)

				if total_steps_in_simulation > observe:
					base_time = time.time()
					while(time.time() - base_time < 0.4):
						self.replay(observe,deepQLearn)
						# training_set = random.sample(replay,observe)
						# deepQLearn.learn_on_minbatch(training_set,batch_size)
				else:
					time.sleep(0.4)	
				

				nextState,reward,done,info = env.step(vl,vr,action)

				# if step < base:
					# if done:
						# break
					# continue
				cumulated_reward += reward

				#  LEARNING PART
				_,_,error = deepQLearn.process_training_set2([(0,(state,action,reward,nextState,done))] )

				self.memory.add(error[0],(state,action,reward,nextState,done))
				if total_steps_in_simulation > observe:
					
					# if len(self.memory) > max_buffer_size:
					# 	self.memory.pop(0)

					#Train
					self.replay(observe,deepQLearn)  # or observe

					
					# deepQLearn.learn_on_minbatch(training_set,batch_size)
					# deepQLearn.learn_on_one_example(state,action,reward,nextState,done,batch_size = batch_size)

				if not(done):
					state = nextState
				else:
					print('done')
					break
				print("Episode ,Step = ",episode,step)

				#  Average time per step = 0.004s

				total_steps_in_simulation += 1

				
					
				
			stepList.append(step)
			rewardList.append(cumulated_reward)


			m, s = divmod(int(time.time() - start_time), 60)
			h, m = divmod(m, 60)

			fl = open('Files/summary.txt','a')
			print ("\n\n\EP "+str(episode+1)+" Reward: "+ str(cumulated_reward)  +" Time: %d:%02d:%02d" % (h, m, s),'epsilon = '+ str(self.epsilon)+ ' Step = ',str(step),"Total Step Count = ",total_steps_in_simulation,file=fl)                 
			
			# time.sleep(0.5)
			# if (episode+1)%500 == 0:
			# 	print("\n\n\nREPLAY MEMORY :", replay,file=fl)

				
			if (episode +1)%50== 0:
				# print(replay)

				deepQLearn.update_target_model()
				rewardList = pickle.load(open(self.rewardFile, 'rb'))  + rewardList
				stepList = pickle.load(open(self.stepFile, 'rb'))  + stepList 
				# print(len(rewardList))
				#print(stepList)

				pickle.dump(rewardList, open(self.rewardFile, 'wb'))
				pickle.dump(stepList, open(self.stepFile, 'wb'))

				''' COMMMENT THESE IF TESTING ANYTHING TO PREVENT DATA DAMAGE'''

				deepQLearn.saveModel(self.savePath+str(file_count + index)+'.h5')
				index = index + 1
				
				deepQLearn.saveQValues(episode)
				deepQLearn.saveWeights(episode)

				stepList = []
				rewardList = []
				# print(self.dict)
				
				# print values
				f = open('Files/deep_q_table.txt','a')
				print(episode + 1,file = f)


				print_state = np.empty((0,3))
				print_state = np.append(print_state,[0,0,0,0.05,0.05])

				for i in range(13,35,3):
					print_state[0] = i/100
					for j in range(13,35,3):
						print_state[1] = j/100
						for k in range(13,35,3):
							print_state[2] = k/100
							qValues = deepQLearn.getQValues(print_state)
							action = deepQLearn.selectAction(qValues, 0 )# no randomness 
							print(print_state , " ", action, file = f)
		
				f.close()

	def replay(self,BATCH_SIZE, deepQLearn):    
		batch = self.memory.sample(BATCH_SIZE)
		x, y, errors = deepQLearn.process_training_set2(batch)

		#update errors
		for i in range(len(batch)):
			idx = batch[i][0]
			self.memory.update(idx, errors[i])
			# print(errors[i],batch[i])
		deepQLearn.learn_on_minbatch(x, y,self.batch_size)


# -------------------- MEMORY --------------------------
class Memory:   # stored as ( s, a, r, s_ ) in SumTree
	e = 0.01
	a = 0.6

	def __init__(self, capacity):
		self.tree = SumTree(capacity)

	def _getPriority(self, error):
		return (error + self.e) ** self.a

	def add(self, error, sample):
		p = self._getPriority(error)
		self.tree.add(p, sample) 

	def sample(self, n):
		batch = []
		segment = self.tree.total() / n

		for i in range(n):
			a = segment * i
			b = segment * (i + 1)

			s = random.uniform(a, b)
			(idx, p, data) = self.tree.get(s)
			batch.append( (idx, data) )
			# print(data, "=",p,s)
		return batch

	def update(self, idx, error):
		p = self._getPriority(error)
		self.tree.update(idx, p)





if __name__ == '__main__':
	agent = Agent()
	agent.start()
